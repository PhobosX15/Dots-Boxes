package dots;

public class Grid {
	
	private String gridImage; //33,55,77

	public String getGridImage() {
		return gridImage;
	}

	public void setGridImage(String gridImage) {
		this.gridImage = gridImage;
	}

	public Grid(String gridImage) {
		super();
		this.gridImage = gridImage;
	}
		
	
}
