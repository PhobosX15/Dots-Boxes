package dots;

public class Main {

	public static final int SCREEN_WIDTH = 1170;
	public static final int SCREEN_HEIGHT = 720;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Dots();
		
	}

}
